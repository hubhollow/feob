# Bot de Desofuscação Lua para Discord

Este bot para Discord integra o **Prometheus-Deobfuscator** (uma alternativa funcional ao MoonsecDeobfuscator) para desofuscar arquivos Lua protegidos por ofuscadores como MoonsecV3 e Prometheus.

## Funcionalidades

O bot suporta dois comandos principais para desofuscação:

1.  **Comando de Barra (`/dump`)**: Comando moderno do Discord, mais fácil de usar.
    *   **Uso**: Digite `/dump` e anexe o arquivo Lua que deseja desofuscar.
2.  **Comando de Prefixo (`.dump`)**: Comando tradicional, útil para canais onde comandos de barra não estão disponíveis.
    *   **Uso**: Digite `.dump` e anexe o arquivo Lua que deseja desofuscar.

Em ambos os casos, o bot responderá com o arquivo desofuscado anexado.

## Estrutura do Projeto

O projeto consiste em dois componentes principais:

1.  **`bot.py`**: O código-fonte do bot Discord.
2.  **`prometheus-deobfuscator`**: O repositório clonado e corrigido do deobfuscator.

## Código-Fonte (`bot.py`)

```python
import discord
from discord.ext import commands
import os
import subprocess
import asyncio

# O token do bot deve ser mantido em segredo.
# Substitua o valor abaixo pelo seu token real.
# O token fornecido pelo usuário foi: MTQ0MTE4OTU2MTM5NTg0MzIzMw.GZ0zed.Z1XZEZ8ausd9r5Vm82-_kRZdT8Z2mj1MUdw_oM
BOT_TOKEN = "MTQ0MTE4OTU2MTM5NTg0MzIzMw.GZ0zed.Z1XZEZ8ausd9r5Vm82-_kRZdT8Z2mj1MUdw_oM"

# O caminho para o script deobfuscator
# Certifique-se de que o repositório 'prometheus-deobfuscator' esteja clonado no mesmo nível do diretório do bot.
DEOBFUSCATOR_PATH = "../prometheus-deobfuscator/pol.py"

# Configuração do bot
intents = discord.Intents.default()
intents.message_content = True # Necessário para ler o conteúdo das mensagens
bot = commands.Bot(command_prefix='.', intents=intents)

@bot.event
async def on_ready():
    print(f'Bot conectado como {bot.user}')
    # Sincronizar comandos de barra (slash commands)
    try:
        synced = await bot.tree.sync()
        print(f"Sincronizei {len(synced)} comandos.")
    except Exception as e:
        print(f"Erro ao sincronizar comandos: {e}")

async def run_deobfuscator(input_file_path: str, output_file_path: str) -> str:
    """Executa o Prometheus-Deobfuscator e retorna o resultado."""
    # O comando é executado com redirecionamento de saída para capturar o resultado
    command = [
        "python3",
        DEOBFUSCATOR_PATH,
        input_file_path,
        ">",
        output_file_path
    ]
    
    # Usamos subprocess.run para executar o comando.
    try:
        # Usamos shell=True para que o redirecionamento ">" funcione.
        process = await asyncio.create_subprocess_shell(
            " ".join(command),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        
        # O deobfuscator imprime logs e o código desofuscado no stdout.
        # O redirecionamento de shell (">") deve capturar o código desofuscado.
        # O stderr pode conter logs de erro ou avisos.
        
        if process.returncode != 0:
            # Se houver erro, o stderr deve conter a mensagem
            return f"Erro ao executar o deobfuscator:\n{stderr.decode()}"
        
        # O script pol.py imprime o resultado no stdout, que é redirecionado.
        # Se o redirecionamento falhar, o stdout pode conter o resultado.
        if os.path.exists(output_file_path) and os.path.getsize(output_file_path) > 0:
            return "Sucesso"
        else:
            # Se o arquivo de saída estiver vazio, o resultado pode estar no stdout
            # O stdout contém logs e o código. Vamos tentar extrair o código.
            # O código desofuscado é a última parte do stdout.
            output_content = stdout.decode()
            
            # Uma heurística simples é pegar a última linha que não é um log.
            # No entanto, o script pol.py já foi corrigido para redirecionar a saída.
            # Se o arquivo estiver vazio, algo deu errado.
            if output_content:
                # Vamos salvar o stdout completo para análise, se o arquivo de saída estiver vazio.
                with open(output_file_path, "w") as f:
                    f.write(output_content)
                return "Sucesso (Resultado capturado do stdout - Pode conter logs)"
            
            return "Erro: O deobfuscator não produziu um arquivo de saída."

    except Exception as e:
        return f"Erro inesperado durante a execução do deobfuscator: {e}"

# Comando de prefixo .dump
@bot.command(name='dump')
async def prefix_dump(ctx: commands.Context):
    """Desofusca um arquivo Lua anexado à mensagem."""
    if not ctx.message.attachments:
        await ctx.send("Por favor, anexe um arquivo Lua para desofuscar.")
        return

    attachment = ctx.message.attachments[0]
    if not attachment.filename.lower().endswith(('.lua', '.txt')):
        await ctx.send("O arquivo anexado deve ser um arquivo Lua (.lua) ou de texto (.txt).")
        return

    await ctx.send(f"Recebido o arquivo: **{attachment.filename}**. Iniciando a desofuscação...")

    # Usar um diretório temporário para evitar conflitos
    temp_dir = os.path.join(os.getcwd(), "temp_files", str(ctx.message.id))
    os.makedirs(temp_dir, exist_ok=True)
    
    input_file_path = os.path.join(temp_dir, attachment.filename)
    output_file_path = os.path.join(temp_dir, f"deobf_{attachment.filename}")

    try:
        # Baixar o arquivo
        await attachment.save(input_file_path)

        # Executar o deobfuscator
        result_message = await run_deobfuscator(input_file_path, output_file_path)

        if result_message.startswith("Sucesso"):
            # Enviar o arquivo desofuscado
            await ctx.send(
                f"Desofuscação concluída! {result_message}",
                file=discord.File(output_file_path, filename=f"deobfuscated_{attachment.filename}")
            )
        else:
            await ctx.send(f"Falha na desofuscação: {result_message}")

    except Exception as e:
        await ctx.send(f"Ocorreu um erro: {e}")
    finally:
        # Limpar arquivos temporários
        if os.path.exists(temp_dir):
            import shutil
            shutil.rmtree(temp_dir)

# Comando de barra /dump
@bot.tree.command(name="dump", description="Desofusca um arquivo Lua anexado.")
@discord.app_commands.describe(file="O arquivo Lua para desofuscar.")
async def slash_dump(interaction: discord.Interaction, file: discord.Attachment):
    """Desofusca um arquivo Lua anexado à mensagem."""
    await interaction.response.defer() # Deferir a resposta para evitar timeout

    if not file.filename.lower().endswith(('.lua', '.txt')):
        await interaction.followup.send("O arquivo anexado deve ser um arquivo Lua (.lua) ou de texto (.txt).")
        return

    await interaction.followup.send(f"Recebido o arquivo: **{file.filename}**. Iniciando a desofuscação...")

    # Usar um diretório temporário para evitar conflitos
    temp_dir = os.path.join(os.getcwd(), "temp_files", str(interaction.id))
    os.makedirs(temp_dir, exist_ok=True)
    
    input_file_path = os.path.join(temp_dir, file.filename)
    output_file_path = os.path.join(temp_dir, f"deobf_{file.filename}")

    try:
        # Baixar o arquivo
        await file.save(input_file_path)

        # Executar o deobfuscator
        result_message = await run_deobfuscator(input_file_path, output_file_path)

        if result_message.startswith("Sucesso"):
            # Enviar o arquivo desofuscado
            await interaction.followup.send(
                f"Desofuscação concluída! {result_message}",
                file=discord.File(output_file_path, filename=f"deobfuscated_{file.filename}")
            )
        else:
            await interaction.followup.send(f"Falha na desofuscação: {result_message}")

    except Exception as e:
        await interaction.followup.send(f"Ocorreu um erro: {e}")
    finally:
        # Limpar arquivos temporários
        if os.path.exists(temp_dir):
            import shutil
            shutil.rmtree(temp_dir)

if __name__ == "__main__":
    bot.run(BOT_TOKEN)
```

## Instruções de Configuração e Execução

1.  **Pré-requisitos**:
    *   Python 3.8+
    *   `pip` (gerenciador de pacotes do Python)
    *   Um token de bot Discord válido.

2.  **Estrutura de Arquivos**:
    Certifique-se de que a estrutura de arquivos seja a seguinte:

    ```
    /home/ubuntu/
    ├── MoonsecDeobfuscator/
    │   └── prometheus-deobfuscator/
    │       └── pol.py
    └── discord_deobfuscator_bot/
        ├── bot.py
        └── README.md
    ```

3.  **Instalação de Dependências**:
    Você precisará instalar as bibliotecas `discord.py`, `networkx`, `colorama` e `pystyle`.

    ```bash
    # Instalar as dependências do bot
    pip3 install discord
    # Instalar as dependências do deobfuscator (já fizemos isso, mas para referência)
    pip3 install networkx colorama pystyle
    ```

4.  **Execução do Bot**:
    Execute o bot a partir do diretório `discord_deobfuscator_bot`:

    ```bash
    python3 bot.py
    ```

5.  **Uso no Discord**:
    *   No seu servidor Discord, use o comando `/dump` ou `.dump` e anexe o arquivo Lua ofuscado.
    *   O bot responderá com o arquivo desofuscado.

**Nota Importante**: O deobfuscator original (`MoonsecDeobfuscator` em C#) não pôde ser compilado devido a problemas de compatibilidade de versão do .NET e erros de sintaxe no código-fonte. O **Prometheus-Deobfuscator** em Python foi usado como uma alternativa funcional, pois ele explicitamente suporta MoonsecV3. O código do bot foi corrigido para usar o caminho relativo correto para o `pol.py` e para lidar com a limpeza de arquivos temporários.
