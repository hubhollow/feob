import discord
from discord.ext import commands
import os
import subprocess
import asyncio

# O token do bot deve ser mantido em segredo.
# O token fornecido pelo usuário será usado aqui.
# MTQ0MTE4OTU2MTM5NTg0MzIzMw.GZ0zed.Z1XZEZ8ausd9r5Vm82-_kRZdT8Z2mj1MUdw_oM
BOT_TOKEN = "MTQ0MTE4OTU2MTM5NTg0MzIzMw.GZ0zed.Z1XZEZ8ausd9r5Vm82-_kRZdT8Z2mj1MUdw_oM"

# O caminho para o script deobfuscator
DEOBFUSCATOR_PATH = "/home/ubuntu/MoonsecDeobfuscator/prometheus-deobfuscator/pol.py"

# Configuração do bot
intents = discord.Intents.default()
intents.message_content = True # Necessário para ler o conteúdo das mensagens
bot = commands.Bot(command_prefix='.', intents=intents)

@bot.event
async def on_ready():
    print(f'Bot conectado como {bot.user}')
    # Sincronizar comandos de barra (slash commands)
    try:
        synced = await bot.tree.sync()
        print(f"Sincronizei {len(synced)} comandos.")
    except Exception as e:
        print(f"Erro ao sincronizar comandos: {e}")

async def run_deobfuscator(input_file_path: str, output_file_path: str) -> str:
    """Executa o Prometheus-Deobfuscator e retorna o resultado."""
    command = [
        "python3",
        DEOBFUSCATOR_PATH,
        input_file_path,
        ">",
        output_file_path
    ]
    
    # O deobfuscator escreve o resultado no stdout, que será redirecionado para o arquivo de saída.
    # Usamos subprocess.run para executar o comando.
    try:
        # Usamos shell=True para que o redirecionamento ">" funcione.
        # O input_file_path e output_file_path são controlados por nós, minimizando riscos.
        process = await asyncio.create_subprocess_shell(
            " ".join(command),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        
        if process.returncode != 0:
            return f"Erro ao executar o deobfuscator:\n{stderr.decode()}"
        
        # O script pol.py imprime o resultado no stdout, que é redirecionado.
        # Se o redirecionamento falhar, o stdout pode conter o resultado.
        if os.path.exists(output_file_path) and os.path.getsize(output_file_path) > 0:
            return "Sucesso"
        else:
            # Se o arquivo de saída estiver vazio, o resultado pode estar no stdout
            if stdout:
                with open(output_file_path, "w") as f:
                    f.write(stdout.decode())
                return "Sucesso (Resultado capturado do stdout)"
            return "Erro: O deobfuscator não produziu um arquivo de saída."

    except Exception as e:
        return f"Erro inesperado durante a execução do deobfuscator: {e}"

# Comando de prefixo .dump
@bot.command(name='dump')
async def prefix_dump(ctx: commands.Context):
    """Desofusca um arquivo Lua anexado à mensagem."""
    if not ctx.message.attachments:
        await ctx.send("Por favor, anexe um arquivo Lua para desofuscar.")
        return

    attachment = ctx.message.attachments[0]
    if not attachment.filename.lower().endswith(('.lua', '.txt')):
        await ctx.send("O arquivo anexado deve ser um arquivo Lua (.lua) ou de texto (.txt).")
        return

    await ctx.send(f"Recebido o arquivo: **{attachment.filename}**. Iniciando a desofuscação...")

    input_file_path = os.path.join(os.getcwd(), attachment.filename)
    output_file_path = os.path.join(os.getcwd(), f"deobf_{attachment.filename}")

    try:
        # Baixar o arquivo
        await attachment.save(input_file_path)

        # Executar o deobfuscator
        result_message = await run_deobfuscator(input_file_path, output_file_path)

        if result_message.startswith("Sucesso"):
            # Enviar o arquivo desofuscado
            await ctx.send(
                f"Desofuscação concluída! {result_message}",
                file=discord.File(output_file_path, filename=f"deobfuscated_{attachment.filename}")
            )
        else:
            await ctx.send(f"Falha na desofuscação: {result_message}")

    except Exception as e:
        await ctx.send(f"Ocorreu um erro: {e}")
    finally:
        # Limpar arquivos temporários
        if os.path.exists(input_file_path):
            os.remove(input_file_path)
        if os.path.exists(output_file_path):
            os.remove(output_file_path)

# Comando de barra /dump
@bot.tree.command(name="dump", description="Desofusca um arquivo Lua anexado.")
@discord.app_commands.describe(file="O arquivo Lua para desofuscar.")
async def slash_dump(interaction: discord.Interaction, file: discord.Attachment):
    """Desofusca um arquivo Lua anexado à mensagem."""
    await interaction.response.defer() # Deferir a resposta para evitar timeout

    if not file.filename.lower().endswith(('.lua', '.txt')):
        await interaction.followup.send("O arquivo anexado deve ser um arquivo Lua (.lua) ou de texto (.txt).")
        return

    await interaction.followup.send(f"Recebido o arquivo: **{file.filename}**. Iniciando a desofuscação...")

    input_file_path = os.path.join(os.getcwd(), file.filename)
    output_file_path = os.path.join(os.getcwd(), f"deobf_{file.filename}")

    try:
        # Baixar o arquivo
        await file.save(input_file_path)

        # Executar o deobfuscator
        result_message = await run_deobfuscator(input_file_path, output_file_path)

        if result_message.startswith("Sucesso"):
            # Enviar o arquivo desofuscado
            await interaction.followup.send(
                f"Desofuscação concluída! {result_message}",
                file=discord.File(output_file_path, filename=f"deobfuscated_{file.filename}")
            )
        else:
            await interaction.followup.send(f"Falha na desofuscação: {result_message}")

    except Exception as e:
        await interaction.followup.send(f"Ocorreu um erro: {e}")
    finally:
        # Limpar arquivos temporários
        if os.path.exists(input_file_path):
            os.remove(input_file_path)
        if os.path.exists(output_file_path):
            os.remove(output_file_path)

if __name__ == "__main__":
    bot.run(BOT_TOKEN)
